<template>
    <div class='nav'>
        <div class='logo'></div>
        <div class='input'>
            <input type='text' placeholder='免押金租电脑'>
            <span class='icon search'></span>
        </div>
        <span class="denglu" @click="goLogin">登录</span>
    </div>
</template>

<script>
export default {
    methods:{
        goLogin(){
            this.$router.push('/login')
        }
    }
}
</script>
