<template>
    <div class="hotsaleMain">
         <div class="zujiHeader hotsaleHeader">
           <div class="zujilogo"><span></span></div> 
            <h2>热销机型</h2>
        </div>
        <div class="hotsaleTu">
            <ul>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
                <li>
                    <div class="hotsaleImg"></div>
                    <p class="p1">ThinkPad X220 12.5英寸便携笔记本电脑</p>
                    <p class="p2">￥70/月</p>
                </li>
            </ul>
        </div>
    </div>
</template>