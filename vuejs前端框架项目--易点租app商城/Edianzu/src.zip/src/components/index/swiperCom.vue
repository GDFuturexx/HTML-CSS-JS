<template>
    <div class="swiper-container" :style="{width:width,height:height}">
        <div class="swiper-wrapper">
            <div class="swiper-slide"  v-for='item in imgList' :key="item" :style='{background:"url("+ item +")"}' ></div>
            
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination" :style="{top:top}"></div>
        
        <!-- 如果需要导航按钮
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>-->
        
        <!-- 如果需要滚动条 -->
        <!-- <div class="swiper-scrollbar"></div> --> 
    </div>
</template>

<script>
import factory from '@/assets/js/swiper.js'
// import test from '@/assets/js/test.js'
import '@/assets/css/swiper.css'
    export default{
        data:function(){
            return {
               
            }
        },
        props:['width','height','imgList','top'],
        mounted() {
            
            var Swiper = factory()
            var mySwiper = new Swiper ('.swiper-container', {// eslint-disable-line no-unused-vars
                loop: true,
                autoplay:true,
                
                // 如果需要分页器
                pagination: {
                el: '.swiper-pagination',
                },
                
                // 如果需要前进后退按钮
                // navigation: {
                // nextEl: '.swiper-button-next',
                // prevEl: '.swiper-button-prev',
                // },
            })        
        },  
    }

</script>

<style>
    .swiper-container {
    width: 7.5rem;
    height: 3.5rem;
} 
.swiper-container .swiper-slide{
    background-size:100% 100% !important;
    background-position:50% !important;
}
.swiper-pagination{
    top: 2.2rem;
}
.swiper-pagination-bullet-active{
    background: rgb(228, 80, 80);
}
.swiper-pagination-bullet{
    width: 0.22rem;
    height: 0.22rem;
    border-radius: 0.11rem;
}
</style>