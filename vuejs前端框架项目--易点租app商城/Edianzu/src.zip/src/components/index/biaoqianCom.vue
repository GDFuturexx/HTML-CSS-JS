<template>
    <div class="biaoqianMain">
        <div class="bq bq1">
            <span></span>
            <p>免押金</p>
        </div>
        <div class="bq bq2">
            <span></span>
            <p>随租随还</p>
        </div>
        <div class="bq bq3">
            <span></span>
            <p>按月支付</p>
        </div>
        <div class="bq bq4">
            <span></span>
            <p>全程保修</p>
        </div>
    </div>
</template>