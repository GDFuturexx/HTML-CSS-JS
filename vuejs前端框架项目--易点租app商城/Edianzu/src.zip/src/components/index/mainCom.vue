<template>
    <div>
        <swiperCom :imgList='imgList'></swiperCom>
        <biaoqianCom></biaoqianCom>
        <sanfenzhongZujiCom></sanfenzhongZujiCom>
        <hotsaleCom></hotsaleCom>
        <workCom></workCom>
        <jishuCom></jishuCom>
        <shangwuCom></shangwuCom>
        <tuxingCom></tuxingCom>
        <waisheCom></waisheCom>
    </div>
</template>

<script>
import swiperCom from '@/components/index/swiperCom.vue'
import biaoqianCom from '@/components/index/biaoqianCom.vue'
import sanfenzhongZujiCom from '@/components/index/sanfenzhongZujiCom.vue'
import hotsaleCom from '@/components/index/hotsaleCom.vue'
import workCom from '@/components/index/workCom.vue'
import jishuCom from '@/components/index/jishuCom.vue'
import shangwuCom from '@/components/index/shangwuCom.vue'
import tuxingCom from '@/components/index/tuxingCom.vue'
import waisheCom from '@/components/index/waisheCom.vue'

import data from '@/data/data.js'

export default {
  name: 'home',
    data:function(){
    return {
        productList :data.products,
        imgList:[
            "https://edzimg.edianzu.com/homepage/bdafed9eeb8074cd6be94cf771ee9c17.jpg",
            "https://edzimg.edianzu.com/homepage/d7449860c947886dcfe9432cd91f4d95.png",
            "https://edzimg.edianzu.com/homepage/e7abad6be5faa6def8c0330761781c83.jpg",
            "https://edzimg.edianzu.com/homepage/6c45567328b22114c22db958d37d28b5.jpg",
            "https://edzimg.edianzu.com/homepage/1d935ab08bbb8aa905484038efb52e55.jpg",
            "https://edzimg.edianzu.com/homepage/1ce227496a97deeb624329cb48a3c433.jpg",
            "https://edzimg.edianzu.com/homepage/80e6e5eda9a01468c7b449912bb12494.jpg"
            ]
    }  
        },
        components: {
          swiperCom,
          biaoqianCom,
          sanfenzhongZujiCom,
          hotsaleCom,
          workCom,
          jishuCom,
          shangwuCom,
          tuxingCom,
          waisheCom

  }
}
</script>