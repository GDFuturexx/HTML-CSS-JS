<template>
    <div class="zujiMain">
        <div class="zujiHeader">
           <div class="zujilogo"><span></span></div> 
            <h2>3分钟轻松租机</h2>
        </div>
        <div class="zujiContent">
            <div class="zjcTu"></div>
            <ul>
                <li>
                    1分钟</br>
                    选择机型
                </li>
                <li>
                     1分钟</br>
                    获得免押金额度
                </li>
                <li>
                     1分钟</br>
                    提交订单
                </li>
            </ul>
        </div>
        <div class="zujiFooter">
            <input type="text" placeholder="输入您的手机号" class="input">
            <a class="btn">我想租赁</a>
        </div>
    </div>
</template>