<template>
        <div class="bottom">
			<div class="shouye">
				<span class="iconfont icon-shouye" :class="{active:$route.name=='home'}"></span>
				<span class="Text" :class="{active:$route.name=='home'}" @click="goIndex">首页</span>
			</div>
			<div class="wuliu">
				<span class="iconfont icon-fenlei" :class="{active:$route.name=='category'}"></span>
				<span class="Text" :class="{active:$route.name=='category'}" @click="goCategory">分类</span>
			</div>
			<div class="buy">
				<span style="margin-left: 6px;" class="iconfont icon-gouwuche" :class="{active:$route.name=='buyCar'}"></span>
				<span style="width: 36px;" class="Text" :class="{active:$route.name=='buyCar'}" @click="goGowuche">购物车</span>
			</div>
			<div class="more">
				<span class="iconfont icon-wode" :class="{active:$route.name=='login'}"></span>
				<span class="Text" :class="{active:$route.name=='login'}" @click="gomy">我的</span>
			</div>
		</div>
</template>


<script>
export default {
    data:function () {
        return {}
    },
    methods:{
        goIndex:function() {
            this.$router.push({path:'/'})
        },
        goCategory:function() {
            this.$router.push('/category')
		},
		goGowuche:function() {
			this.$router.push('/buyCar')
		},
		gomy:function() {
			this.$router.push('/login')
        },
    },
    mounted() {
        // console.log(this)
    },
}
</script>

<style>
    .active{
        color: #1aa2f0 !important;
    }
    .bottom {
	display: flex;
	justify-content: space-around;
	width: 7.5rem;
	height: 1rem;
	position: fixed;
	left: 0;
	bottom: 0;
	background-color: white;
	z-index: 100;
	border-top: 0.2px solid #ccc;
}

.bottom span {
	display: block;
}

.bottom
/*.wuli,.more,.shouye */

.iconfont {
	font-size: 22px;
	width: 24px;
	height: 22px;
	line-height: 22px;
	color: #5D656B;
	align-content: center;
	margin-top: 5px;
}

.bottom .Text {
	width: 24px;
	height: 16px;
	font-size: 12px;
	align-content: center;
	color: #5d656b;
}
</style>
