<template>
    <div class="kongbai"></div>
</template>

<style>
    .kongbai{
        height: 6rem;
        width: 7.5rem;
        background: white;
    }
</style>