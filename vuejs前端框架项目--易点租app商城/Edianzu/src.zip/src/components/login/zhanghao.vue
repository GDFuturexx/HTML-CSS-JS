<template>
    <div class='form' id="zhanghao" >
                <div>
                    <span>账号：</span>
                    <input type="text" id="zhanghao1" placeholder="用户名 / 绑定手机号">
                </div>
                <div>
                   <span>密码：</span>
                    <input type="password" id="password" placeholder="请输入密码">
                </div>
                <div>
                    <span>图片验证码：</span>
                    <input type="text" id="checknumber1" placeholder="请输入图片验证码">
                </div>
                
            </div>
</template>




