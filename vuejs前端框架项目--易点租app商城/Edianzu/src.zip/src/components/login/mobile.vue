<template>
    <div class='form' id="mobile" >
                <div>
                    <span>手机号：</span>
                    <input type="text" id="shouji" placeholder="请输入手机号">
                </div>
               
                <div>
                    <span>短信验证码：</span>
                    <input type="text" id="duanxin" placeholder="请输入短信验证码">
  <div class='serviceCode'>
    <span v-show="sendAuthCode" class="auth_text auth_text_blue"  @click="getAuthCode" style='cursor:pointer'>获取验证码</span>
    <span v-show="!sendAuthCode" class="auth_text" style='cursor:pointer'> <span class="auth_text_blue" style='cursor:pointer'>{{auth_time}} </span>s重新发送</span>
  </div>
                </div>
                 <div>
                    <span>图片验证码：</span>
                    <input type="password" id="checknumber2" placeholder="请输入图形验证码">
     <div class="code" @click="refreshCode">
    <s-identify :identifyCode="identifyCode"></s-identify>
  </div>
                </div>

                
    </div>
</template>

<script>
import SIdentify from '@/components/index/identify.vue'
export default {
    data(){
        return{
    sendAuthCode:true,/*布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */
    auth_time: 60, /*倒计时 计数器*/
   
    auth_timetimer:'',
    
    identifyCodes: "1234567890",
      identifyCode: "",
        }
    },
     mounted() {
    this.identifyCode = "";
    this.makeCode(this.identifyCodes, 4);
  },
    methods:{
        getAuthCode() {
  this.sendAuthCode = false;
  this.auth_time = 60;
  this.auth_timetimer =  setInterval(()=>{
      this.auth_time--;
  if(this.auth_time<=0){
    this.sendAuthCode = true;
    clearInterval(this.auth_timetimer);
  }
  }, 1000);
},

randomNum(min, max) {
      return Math.floor(Math.random() * (max - min) + min);
    },
    refreshCode() {
      this.identifyCode = "";
      this.makeCode(this.identifyCodes, 4);
    },
    makeCode(o, l) {
      for (let i = 0; i < l; i++) {
        this.identifyCode += this.identifyCodes[
          this.randomNum(0, this.identifyCodes.length)
        ];
      }
      // console.log(this.identifyCode);
    }
    },
    components:{
        SIdentify,
    }
}
</script>

<style>
.code {
  width: 2.24rem !important;
  height:0.76rem !important;
  position: absolute;
  top: 2.3rem;
  left: 4.5rem;
  border-bottom: none !important;
  z-index: 100;
}
.s-canvas{
border-bottom: none !important;
}
</style>
