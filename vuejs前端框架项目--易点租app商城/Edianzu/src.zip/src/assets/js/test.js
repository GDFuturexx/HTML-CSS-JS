
var test = function(){
    console.log(this)
    console.log(window)
}


export default test