import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    buyCar:{
      num:0,
      carList:[],
    }
  },
  mutations: {
    addproducts:function(state,content){
      state.buyCar.carList.push(content)
      var count = 0
      //将carList的内容进行循环
      state.buyCar.carList.forEach(function(item){
          count = count+item.num
      })
      state.buyCar.num=count
    },
  

      addCarNum(state,index){
        // console.log(state)
        state.buyCar.carList[index].num ++
      },
      jianCarNum(state, index) {
        // console.log(state)
        state.buyCar.carList[index].num--
      },
      delCarList(state,index){
        state.buyCar.carList.splice(index,1)
      },
      sortNum(state){
        var count = 0
        state.buyCar.carList.forEach(function (item) {
          count = count + item.num
        })
        state.buyCar.num = count
      },
    },

  actions: {

  }
})
