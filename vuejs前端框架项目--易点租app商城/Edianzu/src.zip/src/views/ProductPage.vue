<template>
    <div class='productPage'>
        <div class="productNav"><span @click="goCategory"></span>
        商品详情</div>
        <hr>
        <div style="height:0.7rem;"></div>
        <swiperCom :imgList='imgList' width='7.5rem' height='7.5rem' top='7.2rem' ></swiperCom>
        <h1 class="proContent">{{product.name}}
            <span></span>
        </h1>
        <hr>
        <div class="chooseProduct">
            <h3>选择商品:</h3>
            <div class="choose">
                <button :class="{active:productIndex==index}" v-for="(item,index) in product.productList" :key="index" @click='toggleProduct(index)'>{{item.name}}</button>
            
            </div>
            
        </div>
        <hr>
        <div class="chooseZulin">
            <h3>租赁方式:</h3>
            <div class="choose">
                <button :class="{active:zulinIndex==i}" v-for="(item,i) in product.zulin" :key="i" @click='toggleZulin(i)'>
                    <h4>月租金￥{{item.price}},租期{{item.time}}个月</h4>
                    <h4 >{{item.moshi}}: <span v-if="item.moshi=='随租随还'" style="color:rgb(228,80,80);padding-left:0.3rem;">到期归还易点租，6个月后可随时退还</span><span v-else style="color:rgb(228,80,80);padding-left:0.3rem;">到期归承租方，不可退还</span></h4>
                </button>
            
            </div>
            
        </div>
        <hr>
        <div class='result'>
            <h4 class="h4_1">
                <span>起租日期：</span><input type="date" v-model="time">
            </h4>
            <h4 class="h4_2">
                <span class="hehe">数量：</span>
                <div class="shuzikuang">
                <span @click="jianNum">-</span>
                <span>{{num}}</span>
                <span @click="addNum">+</span>
                </div>
            </h4>
            <h4 class="h4_3">
                <span>售后：</span>
                <span>{{this.product.shouhou}}</span>
                
            </h4>
            <h4 class="h4_4">
                <span>押金：</span>
                <span>￥{{product.productList[this.productIndex].price*num}}.00</span>
                
            </h4>
            <h4 class="h4_5">
                <span>租金：</span>
                <span>￥{{product.zulin[this.zulinIndex].price*num}}.00</span>       
            </h4>
            <kongbai></kongbai>
        </div>
     

        
        

        <div class="bottom">
			<div class="shouye">
				<span class="iconfont icon-shouye" :class="{active:$route.name=='home'}"></span>
				<span class="Text" :class="{active:$route.name=='home'}" @click="goIndex">首页</span>
			</div>
			<div class="wuliu">
				<span class="iconfont icon-fenlei" :class="{active:$route.name=='category'}"></span>
				<span class="Text" :class="{active:$route.name=='category'}" @click="goCategory">分类</span>
			</div>
			<div class="buy">
				<span style="margin-left: 0.3rem;" class="iconfont icon-gouwuche" :class="{active:$route.name=='buyCar'}"></span>
				<span style="width: 36px;" class="Text" :class="{active:$route.name=='buyCar'}" @click="goGowuche">购物车</span>
			</div>
            <button @click="addbuyCar">加入购物车</button>
           <span class="gouwuchushuliang" >{{$store.state.buyCar.num}}</span>
           <!-- v-if='$store.state.buyCar.num!==0' -->
		</div>
       
        <!-- <tabBtn></tabBtn> -->
    </div>
</template>


<script>
import swiperCom from '@/components/index/swiperCom.vue';
import kongbai from '@/components/index/kongbai.vue';
// import tabBtn from '@/components/index/tabBtn.vue';
import data from '@/data/data.js'
export default {
    data:function(){
        return {
            product:data.productPage,
            imgList:data.productPage.productList[0].imgList,
            productIndex:0,
            zulinIndex:0,
            time:new Date(),
            num:1
        }
    },
    beforeMount:function () {
      //ajax将产品ID传出去，后端就根据产品ID返回相对应的产品数据（JSON文件）  
    },
    mounted() {
        // console.log(this)
    },
    components:{
        swiperCom,
        // tabBtn,
        kongbai,
    },
    methods: {
        toggleProduct:function (index) {
            this.imgList=this.product.productList[index].imgList
            this.productIndex = index;
        },
        toggleZulin:function (index) {
           
            this.zulinIndex = index;
            //  console.log(this)
        },
        addNum:function () {
            this.num++
        },
        jianNum:function () {
            this.num--
            if(this.num<0){
                this.num=0
            }
        },
        addbuyCar:function(){
            var productBuyCar = {
                num:this.num,
                product:this.product,
                productIndex:this.productIndex,
                zulinIndex:this.zulinIndex,
            }
            //vuex必须得通过commit来提交mutation
            this.$store.commit('addproducts',productBuyCar)
        },
        goIndex:function() {
            this.$router.push({path:'/'})
        },
        goCategory:function() {
            this.$router.push('/category')
		},
		goGowuche:function() {
			this.$router.push('/buyCar')
        },
    },
}


</script>

<style scoped>
.productPage{
    font-size: 0.2rem;
    width: 100%;
    height: 100%;
    /* overflow: scroll ; */
}
.choose button.active{
    border:1px solid red;
}
.bottom {
	display: flex;
	justify-content: space-around;
	width: 7.5rem;
	height: 1rem;
	position: fixed;
	left: 0;
	bottom: 0;
	background-color: white;
    z-index: 100;
    border-top: 0.2px solid #ccc;
}

.bottom span {
	display: block;
}

.bottom
/*.wuli,.more,.shouye */

.iconfont {
	font-size: 22px;
	width: 24px;
	height: 22px;
	line-height: 22px;
	color: #5D656B;
	align-content: center;
    margin-top: 5px;
    margin-left: 0.2rem;
}

.bottom .Text {
	width: 24px;
	height: 16px;
	font-size: 12px;
	align-content: center;
    color: #5d656b;
    margin-left: 0.2rem;
}
.bottom button{
    margin-top: .1rem;
    display: inline-block;
    background: #e45050;
    color: #fff;
    border-radius: .2rem;
    padding: .3rem;
    text-align: center;
    font-size: .3rem;
    line-height: .15rem;
    height: 78%;
}
.bottom .gouwuchushuliang{
    background: #e45050;
    color: #fff;
    border-radius: 0.8rem;
    width: 0.5rem;
    height: 0.3rem;
    padding: .1rem;
    font-size: .3rem;
    line-height: 0.1rem;
    text-align: center;
    position: absolute;
    left: 3.8rem;
    top: 0.1rem;
}
</style>

