<template>
    <div >
        <div class="productNav"><span @click="goIndex"></span>
        登录易点租</div>
        <hr>
        <div class="login-mian">
        <div class="login-tab">
            <div id="btn1" @click="clickZhanghao" :class="zhClass">账号密码登录</div>
            <div></div>
            <div id="btn2" @click='clickMobild' :class="mClass" >手机快捷登录</div>
        </div>
        <div class='com'>
            <!-- <transition name="slide" mode="in-out" >
                <component :is="com"></component>
            </transition> -->
            
            <Zhanghao :class="zhClass"></Zhanghao>
            <Mobile :class="mClass"></Mobile>
        </div>
        <div class="login-btn" @click="goIndex">立即登录</div>
        <div class="login-other">
            <p>立即注册</p>
            <p>忘记密码</p>
        </div>
        </div>

        <tabBtn></tabBtn>
    </div>
</template>


<script>
import Zhanghao from '@/components/login/zhanghao.vue'
import Mobile from '@/components/login/mobile.vue'
import tabBtn from '@/components/index/tabCom.vue'

export default {
    data(){
        return {
            isZhanghao:true,
            com:'Zhanghao',
            zhClass:'',
            mClass:'active',
        }
    },
    methods:{
        clickZhanghao(){
            // this.com = 'Zhanghao';
            this.zhClass=['active','animated','lightSpeedIn']
            this.mClass = ['animated','lightSpeedOut']

        },
        clickMobild(){
            this.mClass=['active','animated','lightSpeedIn']
            this.zhClass = ['animated','lightSpeedOut']
        },
        goIndex:function() {
            //this.$router.push({path:'/'});
            var zhanghao1 = document.querySelector('#zhanghao1').value
            var password = document.querySelector('#password').value
            var shouji = document.querySelector('#shouji').value
            var duanxin = document.querySelector('#duanxin').value
            var checknumber1 = document.querySelector('#checknumber1').value
            var checknumber2 = document.querySelector('#checknumber2').value
            var data1 = {zhanghao1,password,checknumber1}
            var data2 = {shouji,duanxin,checknumber2}

            if(data1['zhanghao1'] != '' ){
                console.log(data1)
            }
            else{
                console.log(data2)
            }
            
            this.$router.push({path:'/'});     
        },
    },
    components:{
        Zhanghao,Mobile,tabBtn,
    }
}
</script>

<style>
    .active{
        color:#1aa2f0;
    }
</style>