<template>
    <div class='buyCar'>
        <div class="productNav"><span @click="goCategory"></span>
        购物车</div>
        <hr style="margin-top:0.7rem;">
        <div class="gouwuchewenzi" v-if="$store.state.buyCar.num==0">
            <div></div>
            <p>购物车里空空的</p>
            <router-link to='/'>去逛逛吧</router-link>
        </div>
        <div class="gouwucheContent" v-else>
            <div style="color:#1aa2f0;border-bottom:6px solid #ccc;display:flex;height:0.7rem;text-align:left;font-size:0.3rem;padding-top:0.1rem;padding-left:0.3rem;font-weight:600;">
               <!-- <input type="checkbox" name="" id=""> -->
                租赁商品</div>
            <div v-for="(item,index) in $store.state.buyCar.carList" :key="index">
                <div class="gwcCon-one">
                    <span id="buycar-yuanquan"></span>
                    <!-- <input type="checkbox" name="" id=""> -->
                <span class="buycar-tupian"><img :src="item.product.productList[item.productIndex].imgUrl" alt=""></span>
                <h3 id="gouwuliebiaoMingcheng">{{item.product.productList[item.productIndex].name}}</h3>
                </div>
                <div class="yuezujin"><h4>月租金：￥{{item.product.zulin[item.zulinIndex].price*item.num}}.00</h4>
                <div class="yzj-one">
                    <span @click='jianNum(index)'>-</span>
                    <span>{{item.num}}</span>
                    <span @click='addNum(index)'>+</span>
                </div>
                <h4 @click="delProduct" style="color:#1296db;">删除</h4>
                </div>
                <h4 id="yajin">押金：￥{{item.product.productList[item.productIndex].price*item.num}}.00</h4>
            </div>
        </div>
        <div style="width:7.5rem;height:1rem;background:white;"></div>


        <div class='alert' v-show="isShow">
            <div @click="shanchu" class="al1"><p>X</p></div>
            <div class="al2"><h3>你将删除所选商品，是否确认？</h3></div>
            <div class="al3">
                <button @click="delSure">确定</button>
                <button @click="shanchu" style="color:black;background-color:white;">取消</button>
            </div>
        </div>
        <div v-for="(item,index) in $store.state.buyCar.carList" :key="index">
        <div class="jiesuan" v-if="$store.state.buyCar.num!==0">
            <span id="buycar-yuanquan"></span>
            <p>全选/取消</p>
            <p id="pppppp">实付款:￥{{totalPrice}}.00</p>
            <div>结算({{totalNum}})</div></div>
        </div>
        <tabBtn></tabBtn>
    </div>
</template>



<script>
import tabBtn from '@/components/index/tabCom.vue'
export default {
    data(){
        return {
            isShow:false,
            delIndex:'',
        }
    },
    methods:{
        addNum(index){
            this.$store.commit('addCarNum',index)
        },
        jianNum(index){
             this.$store.commit('jianCarNum',index)
        },
        delProduct(index){
            this.isShow = true;
            this.delIndex = index
            // this.$store.commit('')
        },
        delSure(){
            this.$store.commit('delCarList',this.delIndex)
            this.$store.commit('sortNum')
            this.isShow = false;
        },
        goCategory:function() {
            this.$router.push('/category')
        },
        shanchu(){
            this.isShow = false
        },
        
    },
    components:{
        tabBtn,
    },
    computed:{
totalPrice(){
var count = 0;
this.$store.state.buyCar.carList.forEach(function (item){
count =item.num*(item.product.productList[item.productIndex].price*item.num)+count;
})
return count;
},
totalNum(){
var count=0;
this.$store.state.buyCar.carList.forEach(function (item){
count =item.num+count;
})
return count;
}
},
}
</script>

<style>
.alert{
    width:5rem;
    height:3rem;
    background:#fff;
    position: absolute;
    top: 50%;
    left: 50%;
    margin-left: -2.5rem;
    margin-top: -1.5rem;
    font-size: 0.25rem;
    border: 1px solid #ccc;  
}
.buyCar{
    font-size: 0.4rem;
}
</style>
